class CustomError extends Error {
  constructor(message, options) {
    super(message, options);
		this.name = 'customError';
  }
}

const SHORTCUT_SAVING_ERROR = 'Błąd! Podczas zapisu skrótu aktywującego wystąpił błąd.';
const JSON_DECODE_ERROR = 'Błąd! Podczas dekodowania odpowiedzi serwera wystąpił błąd.';
const DETAILED_ERROR_MESSAGE = `Szczegóły (oryginalna treść błędu):`;
function optionsPageMessage(textMessage) {
	chrome.storage.session.set({ message: textMessage }).then(() => {
		chrome.runtime.openOptionsPage();
	});
}

chrome.runtime.onInstalled.addListener(details => {
	if (details.reason === 'install') {
		async function setDefaultValues() {
			await chrome.storage.local.set({
				allegroAPIClientId: '',
				allegroAPIClientSecret: '',
				allegroAccessToken: '',
				allegroRefreshToken: '',
				allegroAPIClientIdSandbox: '',
				allegroAPIClientSecretSandbox: '',
				allegroAPIOAuthConnectorSandbox: '',
				allegroAccessTokenSandbox: '',
				allegroRefreshTokenSandbox: ''
			});
		}
			
		setDefaultValues().then(() => {
			optionsPageMessage('Uzupełnij parametry wymagane do działania aplikacji.');
		}).catch(error => {
			optionsPageMessage(`Błąd! Podczas inicjalizacji domyślnych parametrów wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
		});
  }
});

chrome.storage.local.get(['shortcut']).then(result => {
	if (result.shortcut === undefined) {
		chrome.commands.getAll(commands => {
			const assignedShortcut = commands.find(command => command.name === 'changeAuctionTitle' ).shortcut;
			if (assignedShortcut === '') {
				optionsPageMessage(`Błąd! Skrót ${chrome.runtime.getManifest().commands.changeAuctionTitle.suggested_key} jest przypisany do innego rozszerzenia. Ustaw inny skrót aktywujący na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
			} else {
				chrome.storage.local.set({ shortcut: assignedShortcut }).catch(error => { optionsPageMessage(`${SHORTCUT_SAVING_ERROR} ${DETAILED_ERROR_MESSAGE} ${error.message}`) });
			}
		});
	} else {
		chrome.commands.getAll(commands => {
			const assignedShortcut = commands.find(command => command.name === 'changeAuctionTitle' ).shortcut;
			if (assignedShortcut === '') {
				optionsPageMessage(`Błąd! Rozszerzenie nie ma przypisanego skrótu aktywującego. Ustaw go na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
			} else if (assignedShortcut !== result.shortcut) {
				optionsPageMessage(`Nastąpiła zmiana skrótu aktywującego. Nowy skrót to ${assignedShortcut}. Skrót aktywujący możesz ustawić na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
				chrome.storage.local.set({ shortcut: assignedShortcut }).catch(error => { optionsPageMessage(`${SHORTCUT_SAVING_ERROR} ${DETAILED_ERROR_MESSAGE} ${error.message}`) });
			} else {
				chrome.storage.local.set({ shortcut: assignedShortcut }).catch(error => { optionsPageMessage(`${SHORTCUT_SAVING_ERROR} ${DETAILED_ERROR_MESSAGE} ${error.message}`) });
			}
		});
	}
});

(function main() {
  console.log('Załadowano rozszerzenie changeAuctionsTitle');
  chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });
})();	

(async function checkUpdate() {
	let response;
	try {
		response = await fetch('https:/raw.githubusercontent.com/tomsyty/Change-auctions-title/main/current-version');
	} catch (error) {
		chrome.permissions.contains({ permissions: ['notifications'] }).then(granted => {
			if (granted) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({url: 'https://github.com/tomsyty/Change-auctions-title'});
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: ` Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". Sprawdź wersję ręcznie na stronie rozszerzenia.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
			} else {
				optionsPageMessage(`Błąd! Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". ${DETAILED_ERROR_MESSAGE} ${error.message}`);
			}
		});
		return;
	}

	if (response.status === 200) {
		const currentVersion = await response.text();
		if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
			chrome.permissions.contains({ permissions: ['notifications'] }).then(granted => {
				if (granted) {
					chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
						if (buttonIndex === 0) {
							chrome.tabs.create({url: 'https://github.com/tomsyty/Change-auctions-title'});
						}
					});
					chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
				} else {
					optionsPageMessage(`Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`);
				}
			});
		}
	} else {
		console.log('brak pliku z informacją o aktualizacji');
	}
})();

chrome.scripting.getRegisteredContentScripts().then(contentScripts => {
  if (contentScripts === undefined) {
		optionsPageMessage(`Błąd! Nie udało się zarejestrować skryptu.`);
		return;
	}

  if (contentScripts.find(registeredScript => { return registeredScript.id === 'changeAuctionsTitle' }) === undefined) {
    chrome.scripting.registerContentScripts([{
      id: 'changeAuctionsTitle',
      matches: ['https://allegro.pl/moje-allegro/sprzedaz/obsluga-ofert/*', 'https://allegro.pl.allegrosandbox.pl/moje-allegro/sprzedaz/obsluga-ofert/*'],
      css: ['toast.css', 'content_script.css'],
      js: ['toast.js', 'content_script.js']
    }]).then(() => {
      console.log('Załadowano skrypt changeAuctionsTitle');
    });
  }
});

chrome.commands.onCommand.addListener(command => {
  if (command === 'changeAuctionTitle') {
    async function getCurrentTab() {
      const queryOptions = { active: true, currentWindow: true };
      try {
        const [tab] = await chrome.tabs.query(queryOptions);
        return tab.id;
      } catch(error) {
        throw new CustomError('Błąd! Nie udało się uzyskać id aktywnej karty');
      }
    }
    getCurrentTab().then(tab => {
			chrome.storage.local.get(['shortcut']).then(result => {
				chrome.tabs.sendMessage(tab, { action: 'allowEditing', shortcut: result.shortcut }).catch(error => { console.log(`Błąd! Podczas przesyłania wiadomości do aktywnej karty wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`) });
			});
    }).catch(error => {
      if (error.name === 'customError') {
        console.log(error.message);
      } else {
        console.log(`Błąd! Podczas pobierania id aktywnej karty wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`)
      }
    });
  }
});

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	const action = request.action;
	switch (action) {
    case 'getAllegroAccessToken': {
			let sandbox;
			if (request.mode === undefined) sandbox = (sender.url.startsWith('https://allegro.pl.allegrosandbox.pl') ? 'Sandbox' : '');
			else sandbox = (request.mode === 'sandbox' ? 'Sandbox' : '');
			console.log(`Sandbox Mode: ${sandbox}`);
			chrome.storage.local.get([`allegroAccessToken${sandbox}`]).then(result => {
				if (result[`allegroAccessToken${sandbox}`] !== undefined && result[`allegroAccessToken${sandbox}`] !== '') sendResponse({ result: result[`allegroAccessToken${sandbox}`] });
				else {
					throw new CustomError('Błąd! Wymagane jest zalogowanie rozszerzenia do serwisu Allegro, uzupełnij dane dostępowe na stronie opcji rozszerzenia, kliknij zapisz i następnie zaloguj.');
				}
			}).catch(error => {
				throw new CustomError(`Błąd! Podczas odczytu zapisanego tokena dostępowego Allegro wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
			});
			break;
		}
		
		case 'refreshAllegroAccessToken': {
			let sandbox;
			if (request.mode === undefined) sandbox = (sender.url.startsWith('https://allegro.pl.allegrosandbox.pl') ? 'Sandbox' : '');
			else sandbox = (request.mode === 'sandbox' ? 'Sandbox' : '');
			chrome.storage.local.get([`allegroRefreshToken${sandbox}`, `allegroAPIClientId${sandbox}`, `allegroAPIClientSecret${sandbox}`]).then(result => {		
				if (result[`allegroRefreshToken${sandbox}`] !== undefined && result[`allegroRefreshToken${sandbox}`] !== '' && result[`allegroAPIClientId${sandbox}`] !== undefined && result[`allegroAPIClientId${sandbox}`] !== '' && result[`allegroAPIClientSecret${sandbox}`] !== undefined && result[`allegroAPIClientSecret${sandbox}`] !== '') {
					const allegroAPIClientId = result[`allegroAPIClientId${sandbox}`];
					const allegroAPIClientSecret = result[`allegroAPIClientSecret${sandbox}`];
					const allegroRefreshToken = result[`allegroRefreshToken${sandbox}`];
					const redirectUrl = chrome.identity.getRedirectURL('change_auctions_title');

					if (sandbox === 'Sandbox') {
						chrome.storage.local.get(['allegroAPIOAuthConnectorSandbox']).then(result => {
							if (!result.allegroAPIOAuthConnectorSandbox) {
								throw new CustomError('Błąd! Brak wymaganych parametrów (adres skryptu).');
							}
							fetch(result.allegroAPIOAuthConnectorSandbox, {
								method: 'POST',
								headers: {
									'Content-Type': 'application/json'
								},
								body: JSON.stringify({ action: 'refreshTokens', clientId: allegroAPIClientId, clientSecret: allegroAPIClientSecret, refreshToken: allegroRefreshToken })
							}).then(response => {
								if (response.status === 200) {
									const result = response.json();
									result.then(result => {
										if (result?.status === 'success') {
											chrome.storage.local.set({
												allegroAccessTokenSandbox: result.accessToken,
												allegroRefreshTokenSandbox: result.refreshToken
											}).then(() => {
												sendResponse({ result: result.accessToken });
											}).catch(error => {
												throw new CustomError(`Błąd! Odświeżono tokeny dostępowe jednak ich zapis się nie udał. Zaloguj ponownie aplikację celem uzyskania nowych tokenów. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
											});									
										} else if (result?.status === 'error') {
											throw new CustomError(`Błąd! Nie udało się odświeżyć tokenów dostępowych. ${result.details}`);
										} else throw new CustomError('Błąd! Nie udało się odświeżyć tokenów dostępowych.');
									}).catch(error => {
										throw new CustomError(`${JSON_DECODE_ERROR} ${error.message}.`);
									});
								} else {
									throw new CustomError(`Błąd! Podczas odświeżania tokenów wystąpił błąd. Kod odpowiedzi HTTP: ${response.status}.`);
								}
							}).catch(error => {
								console.log(`fetch error: ${error.message}`);
							});
						}).catch(error => {
							throw new CustomError(`Błąd! Podczas odczytu wymaganych parametrów (adres skryptu) wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
						});
					} else {
						(function retry(count = 3) {
							fetch(`https://allegro.pl/auth/oauth/token?grant_type=refresh_token&refresh_token=${allegroRefreshToken}&redirect_uri=${redirectUrl}`, {
								'method': 'POST',
								'headers': {
									'Authorization': `Basic ${btoa(allegroAPIClientId + ':' + allegroAPIClientSecret)}`,
									'Content-Type': 'application/x-www-form-urlencoded'
								}
							}).then(response => {
								if (response.status === 200) {
									result = response.json();
									result.then(result => {
										if (result.access_token !== undefined && result.refresh_token !== undefined) {
											chrome.storage.local.set({ allegroAccessToken: result.access_token, allegroRefreshToken: result.refresh_token }).then(() => {
												sendResponse({ result: result.access_token});
											}).catch(error => {
												throw new CustomError(`Błąd! Odświeżono tokeny dostępowe jednak ich zapis się nie udał. Zaloguj ponownie aplikację na stronie opcji rozszerzenia celem uzyskania nowych tokenów. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
											});
										} else throw new CustomError('Błąd! Serwer Allegro nie zwrócił nowych tokenów dostępowych. Odczekaj chwilę i spróbuj ponownie.');
									}).catch(error => {
										throw new CustomError(`${JSON_DECODE_ERROR} ${error.message}.`);
									});
								} else {
									if (--count) {
										const delay = t => new Promise(resolve => setTimeout(resolve, t));
										delay(3000).then(() => {
											retry(count);
										});
									} else {
										throw new CustomError('Błąd! Nie udało się odświeżyć tokena dostępowego (serwer Allegro nie zwraca prawidłowej odpowiedzi). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');
									}	
								}
							}).catch(error => {
								console.log(`fetch error: ${error.message}`);
								if (--count) {
									const delay = t => new Promise(resolve => setTimeout(resolve, t));
									delay(3000).then(() => {
										retry(count);
									});
								} else {
									throw new CustomError('Błąd! Nie udało się odświeżyć tokena dostępowego (problem podczas wysyłania żądania). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');
								}
							});	
						})();		
					}					
				} else throw new CustomError('Błąd! Brak danych potrzebnych do odświeżenia tokena dostępowego. Zaloguj ponownie aplikację do Allegro na stronie opcji rozszerzenia.');
			}).catch(error => {
				throw new CustomError(`Błąd! Podczas odczytu danych potrzebnych do odświeżenia tokena dostępowego wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
			});
			break;
		}

    case 'allegroAPISave': {
			if (request.clientId !== undefined && request.clientSecret !== undefined && request.oAuthConnector !== undefined && request.sandbox !== undefined) {	
				const sandbox = (request.sandbox === false ? '' : 'Sandbox');
				console.log('Sandbox mode: ' + sandbox);
				let patternClientId = /^|[0-9a-f]{32}/;
				let patternClientSecret = /^|[0-9a-zA-Z]{64}/;
				let patternOAuthConnector = /^|https:\/\/script\.google\.com\/macros\/s\/[0-9a-zA-Z\-_]{1,}\/exec$/;
				if ((patternClientId.test(request.clientId)) && (patternClientSecret.test(request.clientSecret)) && (patternOAuthConnector.test(request.oAuthConnector))) {		
					chrome.storage.local.set({ [`allegroAPIClientId${sandbox}`]: request.clientId, [`allegroAPIClientSecret${sandbox}`]: request.clientSecret, allegroAPIOAuthConnectorSandbox: request.oAuthConnector }).then(() => {
						if (sandbox === 'Sandbox') {
							if (request.clientId !== '' && request.clientSecret !== '' && request.oAuthConnector !== '') sendResponse({ status: 'success', loginButtonDisabled: false });
							else sendResponse({ status: 'success', loginButtonDisabled: true });
						} else {
							if (request.clientId !== '' && request.clientSecret !== '') sendResponse({ status: 'success', loginButtonDisabled: false });
							else sendResponse({ status: 'success', loginButtonDisabled: true });
						}
					}).catch(error => {
						throw new CustomError(`Błąd! Podczas zapisu parametrów wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
					});					
				}	else throw new CustomError('Błąd! Podane wartości parametrów są niepoprawne.');
			} else throw new CustomError('Błąd! Nie podano wartości parametrów Client ID i Cilent Secret.');
			break;
		}

		case 'openLoginPage': {
			if (request.url !== undefined) {
				chrome.tabs.create({ active: true, url: request.url }).then(tab => {
					sendResponse({ status: 'success' });
				}).catch(error => {
					throw new CustomError(`Błąd! Podczas otwierania strony logowania wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
				});
			}
			break;
		}
  }

  return true;
});