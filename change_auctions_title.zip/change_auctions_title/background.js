const SHORTCUT_SAVING_ERROR = 'Podczas zapisu skrótu aktywującego wystąpił błąd.';
const SHORTCUT_READING_ERROR = 'Podczas odczytu skrótu aktywującego wystąpił błąd.';
const JSON_DECODE_ERROR = 'Podczas dekodowania odpowiedzi serwera wystąpił błąd.';
const HTTP_RESPONSE_CODE = 'Kod odpowiedzi HTTP:';
const UNABLE_TO_REFRESH_TOKENS = 'Nie udało się odświeżyć tokenów dostępowych.';
const REFRESHED_TOKENS_SAVE_ERROR = 'Odświeżono tokeny dostępowe jednak ich zapis się nie udał. Zaloguj ponownie aplikację na stronie opcji rozszerzenia celem uzyskania nowych tokenów.';


(function main() {
  console.log('Załadowano rozszerzenie changeAuctionsTitle');
  chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });
	getShortcut();
})();	

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(result); 
    });
  });
}

async function sendMessage(tab, data) {
	return new Promise((resolve, reject) => {
		chrome.tabs.sendMessage(tab, data);
		chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true);
	});
}

function optionsPageMessage(textMessage) {
	chrome.storage.session.set({ message: textMessage }).then(() => {
		chrome.runtime.openOptionsPage();
	});
}

chrome.runtime.onInstalled.addListener(details => {
	if (details.reason === 'install') {
		async function setDefaultValues() {
			try {
				await saveDataToLocalStorage({
					allegroAPIClientId: '',
					allegroAPIClientSecret: '',
					allegroAccessToken: '',
					allegroRefreshToken: '',
					allegroAPIClientIdSandbox: '',
					allegroAPIClientSecretSandbox: '',
					allegroAPIOAuthConnectorSandbox: '',
					allegroAccessTokenSandbox: '',
					allegroRefreshTokenSandbox: ''
				});
				return Promise.resolve('Uzupełnij parametry wymagane do działania aplikacji.');
			} catch (error) {
				return Promise.reject(`Podczas inicjalizacji domyślnych parametrów wystąpił błąd. ${error.message}`);
			}
		}
		setDefaultValues().then(message => {
			optionsPageMessage(message);
		}).catch(error => {
			optionsPageMessage(`Błąd! ${error}`);
		})
  }
		
	(async () => {
		for (const contentScript of chrome.runtime.getManifest().content_scripts) {
			for (const tab of await chrome.tabs.query({ url: contentScript.matches })) {
				try {
					chrome.scripting.insertCSS({
						target: { tabId: tab.id },
						files: contentScript.css
					});
					chrome.scripting.executeScript({
						target: { tabId: tab.id },
						files: contentScript.js
					});
					console.log('Odświeżono skrypty na otwartych stronach.');					
				} catch (error) {
					console.log('Błąd podczas odświeżania stron z aktywnym skryptem.');
				}
			}
		}
	})();
});

chrome.runtime.onSuspend.addListener(function() {
  console.log('*** disconnected ***');
}
);

async function getShortcut() {
	let readedValue;
	let commands;
	try {
		readedValue = await readDataFromLocalStorage(['shortcut']);
	} catch (error) {
		optionsPageMessage(error.message);
	}
	
	if (readedValue.shortcut === undefined) {
		commands = await chrome.commands.getAll();
		const assignedShortcut = commands.find(command => command.name === 'changeAuctionTitle' ).shortcut;
		if (assignedShortcut === '') {
			optionsPageMessage(`Błąd! Skrót ${chrome.runtime.getManifest().commands.changeAuctionTitle.suggested_key} jest przypisany do innego rozszerzenia. Ustaw inny skrót aktywujący na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
		} else {
			try {
				await saveDataToLocalStorage({ shortcut: assignedShortcut });
			} catch (error) {
				optionsPageMessage(`${SHORTCUT_SAVING_ERROR} ${error.message}`);
			}		
		}
	} else {
		commands = await chrome.commands.getAll();
		const assignedShortcut = commands.find(command => command.name === 'changeAuctionTitle' ).shortcut;
		if (assignedShortcut === '') {
			optionsPageMessage(`Błąd! Rozszerzenie nie ma przypisanego skrótu aktywującego. Ustaw go na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
		} else if (assignedShortcut !== readedValue.shortcut) {
			optionsPageMessage(`Nastąpiła zmiana skrótu aktywującego. Nowy skrót to ${assignedShortcut}. Skrót aktywujący możesz ustawić na stronie <a href="chrome://extensions/shortcuts" target="_blank">chrome://extensions/shortcuts</a> (lub w menu Rozszerzenia - Zarządzaj rozszerzeniami - Skróty klawiszowe).`);
			try {
				await saveDataToLocalStorage({ shortcut: assignedShortcut });
			} catch (error) {
				optionsPageMessage(`${SHORTCUT_SAVING_ERROR} ${error.message}`);
			}
		}
	}
}

(async function checkUpdate() {
	let fetchResponse;
	try {
		fetchResponse = await fetch('https:/raw.githubusercontent.com/tomsyty/Change-auctions-title/main/current-version');
	} catch (error) {
		const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
		if (notificationsAllowed) {
			chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
				if (buttonIndex === 0) {
					chrome.tabs.create({ url: 'https://github.com/tomsyty/Change-auctions-title' });
				}
			});
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: ` Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". Sprawdź wersję ręcznie na stronie rozszerzenia.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
		} else {
			optionsPageMessage(`Błąd! Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". ${error.message}`);
		}
		return;
	}

	if (fetchResponse.status === 200) {
		const currentVersion = await fetchResponse.text();
		if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
			const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
			if (notificationsAllowed) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({ url: 'https://github.com/tomsyty/Change-auctions-title' });
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
			} else {
				optionsPageMessage(`Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`);
			}
		}
	} else {
		console.log('brak pliku z informacją o aktualizacji');
	}
})();

chrome.commands.onCommand.addListener(command => {
	asyncOnCommandCallback(command);
	return true;
});
	
async function asyncOnCommandCallback(command) {
  if (command === 'changeAuctionTitle') {
		async function getCurrentTab() {
			const queryOptions = { active: true, currentWindow: true };
			try {
				const [tab] = await chrome.tabs.query(queryOptions);
				return Promise.resolve(tab.id);
			} catch (error) {
				return Promise.reject('Nie udało się uzyskać id aktywnej karty.');
			}
		}
		let tab;
		let readedValue;
		let response;
		try {
			tab = await getCurrentTab();
		} catch (error) {
			optionsPageMessage(`Błąd! ${error}`);
			return;
		}
		try {
			readedValue = await readDataFromLocalStorage(['shortcut']);
		} catch (error) {
			optionsPageMessage(`${SHORTCUT_READING_ERROR} ${error.message}`);
			return;
		}
		try {
			response = await sendMessage(tab, { action: 'allowEditing', shortcut: readedValue.shortcut });
		} catch (error) {
			optionsPageMessage(`Błąd! Podczas przesyłania wiadomości do aktywnej karty wystąpił błąd. ${error.message}`);
			return;
		}
	}
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
	return true;
});

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;
	switch (action) {
    case 'getAllegroAccessToken': {
			let sandbox;
			let readedValue;
			if (request.mode === undefined) sandbox = (sender.url.startsWith('https://allegro.pl.allegrosandbox.pl') ? 'Sandbox' : '');
			else sandbox = (request.mode === 'sandbox' ? 'Sandbox' : '');
			console.log(`Sandbox Mode: ${sandbox}`);
			try {
				readedValue = await readDataFromLocalStorage([`allegroAccessToken${sandbox}`]);
			} catch (error) {
				return Promise.reject(`Podczas odczytu zapisanego tokena dostępowego wystąpił błąd. ${error.message}`);
			}
			if (readedValue[`allegroAccessToken${sandbox}`] !== undefined && readedValue[`allegroAccessToken${sandbox}`] !== '') return Promise.resolve(readedValue[`allegroAccessToken${sandbox}`]);
			else {
				return Promise.reject('Wymagane jest zalogowanie rozszerzenia do serwisu Allegro, uzupełnij dane dostępowe na stronie opcji rozszerzenia, kliknij zapisz i następnie zaloguj.');
			}
		}
		
		case 'refreshAllegroAccessToken': {
			let sandbox;
			let readedValue;
			let fetchResponse;
			let fetchData;
			if (request.mode === undefined) sandbox = (sender.url.startsWith('https://allegro.pl.allegrosandbox.pl') ? 'Sandbox' : '');
			else sandbox = (request.mode === 'sandbox' ? 'Sandbox' : '');
			try {
				readedValue = await readDataFromLocalStorage([`allegroRefreshToken${sandbox}`, `allegroAPIClientId${sandbox}`, `allegroAPIClientSecret${sandbox}`]);
			} catch (error) {
				return Promise.reject(`Podczas odczytu danych potrzebnych do odświeżenia tokena dostępowego wystąpił błąd. ${error.message}`);
			}		
			if (readedValue[`allegroRefreshToken${sandbox}`] === undefined || readedValue[`allegroRefreshToken${sandbox}`] === '' || readedValue[`allegroAPIClientId${sandbox}`] === undefined || readedValue[`allegroAPIClientId${sandbox}`] === '' || readedValue[`allegroAPIClientSecret${sandbox}`] === undefined || readedValue[`allegroAPIClientSecret${sandbox}`] === '') return Promise.reject('Brak danych potrzebnych do odświeżenia tokena dostępowego. Zaloguj ponownie aplikację do Allegro na stronie opcji rozszerzenia.');
			
			const allegroAPIClientId = readedValue[`allegroAPIClientId${sandbox}`];
			const allegroAPIClientSecret = readedValue[`allegroAPIClientSecret${sandbox}`];
			const allegroRefreshToken = readedValue[`allegroRefreshToken${sandbox}`];
			const redirectUrl = chrome.identity.getRedirectURL('change_auctions_title');

			if (sandbox === 'Sandbox') {
				try {
					readedValue = await	readDataFromLocalStorage(['allegroAPIOAuthConnectorSandbox']);
				} catch (error) {
					return Promise.reject(`Podczas odczytu wymaganych parametrów (adres skryptu) wystąpił błąd. ${error.message}`);
				}
				if (!readedValue.allegroAPIOAuthConnectorSandbox) {
					return Promise.reject('Brak wymaganych parametrów (adres skryptu).');
				}

				try {
					fetchResponse = await fetch(readedValue.allegroAPIOAuthConnectorSandbox, {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json'
						},
						body: JSON.stringify({ action: 'refreshTokens', clientId: allegroAPIClientId, clientSecret: allegroAPIClientSecret, refreshToken: allegroRefreshToken })
					});
				} catch (error) {
					return Promise.reject(`Nie udało się uzyskać tokenów dostępowych za pośrednictwem skryptu. ${error.message}`);
				}

				if (fetchResponse.status === 200) {
					try {
						fetchData = await fetchResponse.json();
					} catch (error) {
						return Promise.reject(`${JSON_DECODE_ERROR} ${error.message}.`);
					}
					
					if (fetchData?.status === 'success') {
						try {
							await saveDataToLocalStorage({
								allegroAccessTokenSandbox: fetchData.accessToken,
								allegroRefreshTokenSandbox: fetchData.refreshToken
							});
						} catch (error) {
							return Promise.reject(`${REFRESHED_TOKENS_SAVE_ERROR} ${error.message}`);
						}
						
						return Promise.resolve(fetchData.accessToken);							
					} else if (fetchData?.status === 'error' && fetchData?.details !== undefined) {
						return Promise.reject(`${UNABLE_TO_REFRESH_TOKENS} ${fetchData.details}`);
					} else return Promise.reject(UNABLE_TO_REFRESH_TOKENS);				
				} else {
					return Promise.reject(`Podczas odświeżania tokenów wystąpił błąd. ${HTTP_RESPONSE_CODE} ${fetchResponse.status}.`);
				}
			} else {
				async function login(count = 3) {
					let fetchResponse;
					let fetchData;
					try {
						fetchResponse = await fetch(`https://allegro.pl/auth/oauth/token?grant_type=refresh_token&refresh_token=${allegroRefreshToken}&redirect_uri=${redirectUrl}`, {
							'method': 'POST',
							'headers': {
								'Authorization': `Basic ${btoa(allegroAPIClientId + ':' + allegroAPIClientSecret)}`,
								'Content-Type': 'application/x-www-form-urlencoded'
							}
						});
					} catch (error) {
						if (--count) {
							const delay = t => new Promise(resolve => setTimeout(resolve, t));
							await delay(5000);
							return await login(count);
						} else {
							return Promise.reject('Nie udało się odświeżyć tokena dostępowego (problem podczas wysyłania żądania). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');
						}
					}

					if (fetchResponse.status === 200) {
						try {
							fetchData = await fetchResponse.json();
						} catch (error) {
							return Promise.reject(`${JSON_DECODE_ERROR} ${error.message}.`);
						}

						if (fetchData.access_token === undefined || fetchData.refresh_token === undefined) return Promise.reject('Serwer Allegro nie zwrócił nowych tokenów dostępowych. Odczekaj chwilę i spróbuj ponownie.');

						try {
							await saveDataToLocalStorage({ allegroAccessToken: fetchData.access_token, allegroRefreshToken: fetchData.refresh_token });
						} catch (error) {
							return Promise.reject(`${REFRESHED_TOKENS_SAVE_ERROR} ${error.message}`);
						}
							
						return Promise.resolve(fetchData.access_token);
					} else {
						if (--count) {
							const delay = t => new Promise(resolve => setTimeout(resolve, t));
							await delay(5000)
							return await login(count);
						} else {
							return Promise.reject('Nie udało się odświeżyć tokena dostępowego (serwer Allegro nie zwraca prawidłowej odpowiedzi). Odczekaj chwilę i spróbuj ponownie lub zaloguj aplikację do Allegro na stronie opcji rozszerzenia.');
						}	
					}
				}
				try {
					const result = await login();
					return Promise.resolve(result);
				} catch (error) {
					return Promise.reject(result);
				}
			}					
		}

    case 'allegroAPISave': {
			if (request.clientId === undefined || request.clientSecret === undefined || request.oAuthConnector === undefined || request.sandbox === undefined) return Promise.reject('Nie podano wartości parametrów Client ID i Cilent Secret.');
			const sandbox = (request.sandbox === false ? '' : 'Sandbox');
			console.log('Sandbox mode: ' + sandbox);
			let patternClientId = /^|[0-9a-f]{32}/;
			let patternClientSecret = /^|[0-9a-zA-Z]{64}/;
			let patternOAuthConnector = /^|https:\/\/script\.google\.com\/macros\/s\/[0-9a-zA-Z\-_]{1,}\/exec$/;
			if ((!patternClientId.test(request.clientId)) || (!patternClientSecret.test(request.clientSecret)) || (!patternOAuthConnector.test(request.oAuthConnector))) return Promise.reject('Podane wartości parametrów są niepoprawne.');
			try {
				await saveDataToLocalStorage({ [`allegroAPIClientId${sandbox}`]: request.clientId, [`allegroAPIClientSecret${sandbox}`]: request.clientSecret, allegroAPIOAuthConnectorSandbox: request.oAuthConnector });
				if (request.clientId === '' || request.clientSecret === '' || (sandbox === 'Sandbox' && request.oAuthConnector === '')) await saveDataToLocalStorage({ [`allegroAccessToken${sandbox}`]: '', [`allegroRefreshToken${sandbox}`]: '' });
			} catch (error) {
				return Promise.reject(`Podczas zapisu parametrów wystąpił błąd. ${error.message}`);
			}

			if (sandbox === 'Sandbox') {
				if (request.clientId !== '' && request.clientSecret !== '' && request.oAuthConnector !== '') return Promise.resolve(true);
				else return Promise.resolve(false);
			} else {
				if (request.clientId !== '' && request.clientSecret !== '') return Promise.resolve(true);
				else return Promise.resolve(false);
			}
		}

		case 'openLoginPage': {
			if (request.url !== undefined) {
				let tab;
				try {
					tab = await chrome.tabs.create({ active: true, url: request.url });
				} catch (error) {
					return Promise.reject(`Podczas otwierania strony logowania wystąpił błąd. ${error.message}`);
				}
				return Promise.resolve(true);
			}
			return Promise.reject('Brak wymaganego adresu strony do otwarcia.');
		}
  }
}