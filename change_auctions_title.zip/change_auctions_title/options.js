const JSON_DECODE_ERROR = 'Błąd! Podczas dekodowania odpowiedzi serwera wystąpił błąd.';
const DETAILED_ERROR_MESSAGE = `Szczegóły (oryginalna treść błędu):`;

chrome.storage.onChanged.addListener( (storageObject, storageArea) => {
	if (storageArea === 'session') {
		if ('message' in storageObject && 'newValue' in storageObject.message) {
			toastMessage(storageObject.message.newValue);
			chrome.storage.session.remove('message');
		}
	}
});

window.addEventListener('DOMContentLoaded', () => {
	console.log('--- Załadowano skrypt optionsPage');
	chrome.storage.session.get(['message']).then(result => {
		if (result.message !== undefined) {
			toastMessage(result.message);
			chrome.storage.session.remove('message');
		}
	});

  const redirectUrl = chrome.identity.getRedirectURL('change_auctions_title');
  document.getElementById('chromeExtensionRedirectURL').innerText = redirectUrl;

	document.getElementById('keyboardShortcutChangeLink').addEventListener('click', () => {
		chrome.tabs.create({url: 'chrome://extensions/shortcuts'});
	});

  chrome.storage.local.get(['allegroAPIClientId', 'allegroAPIClientSecret', 'allegroAPIClientIdSandbox', 'allegroAPIClientSecretSandbox', 'allegroAPIOAuthConnectorSandbox'], (result) => {
		if (result.allegroAPIClientId !== undefined && result.allegroAPIClientSecret !== undefined) {	
			const allegroAPIClientIdText = document.getElementById('allegroAPIClientIdText');
			allegroAPIClientIdText.value = result.allegroAPIClientId;
			allegroAPIClientIdText.addEventListener('paste', (e) => {
				e.preventDefault();
				let paste = e.clipboardData.getData('text');
				let patternClientId = /^$|[0-9a-f]{32}/g;
				if (patternClientId.test(paste)) {
					e.target.value = paste;
					const inputsValidity = document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
					document.querySelectorAll('button[class~="allegroAPIButtons"]').forEach(btn => { btn.disabled = !inputsValidity });
				}	
			});
			allegroAPIClientIdText.addEventListener('input', () => {
				const inputsValidity = document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
				document.querySelectorAll('button[class~="allegroAPIButtons"]').forEach(btn => { btn.disabled = !inputsValidity });
			});

			const allegroAPIClientSecretText = document.getElementById('allegroAPIClientSecretText');
			allegroAPIClientSecretText.value = result.allegroAPIClientSecret;
			allegroAPIClientSecretText.addEventListener('paste', (e) => {
				e.preventDefault();
				let paste = e.clipboardData.getData('text');
				let patternClientSecret = /^$|[0-9a-zA-Z]{64}/g;
				if (patternClientSecret.test(paste)) {
					e.target.value = paste;
					const inputsValidity = document.getElementById('allegroAPIClientIdTextSandbox').checkValidity();
					document.querySelectorAll('button[class~="allegroAPIButtons"]').forEach(btn => { btn.disabled = !inputsValidity });
				}	
			});
			allegroAPIClientSecretText.addEventListener('input', () => {
				const inputsValidity =  document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
				document.querySelectorAll('button[class~="allegroAPIButtons"]').forEach(btn => { btn.disabled = !inputsValidity });
			});

		}
		const allegroAPISaveButton = document.getElementById('allegroAPISaveButton');
		allegroAPISaveButton.addEventListener('click', allegroAPISaveButtonClick.bind(null, false));
		const allegroAPILoginButton = document.getElementById('allegroAPILoginButton');
		allegroAPILoginButton.addEventListener('click', allegroAPILoginButtonClick.bind(null, false));
	
		if (result.allegroAPIClientIdSandbox !== undefined && result.allegroAPIClientSecretSandbox !== undefined && result.allegroAPIOAuthConnectorSandbox !== undefined) {	
			const allegroAPIClientIdTextSandbox = document.getElementById('allegroAPIClientIdTextSandbox');
			allegroAPIClientIdTextSandbox.value = result.allegroAPIClientIdSandbox;
			allegroAPIClientIdTextSandbox.addEventListener('paste', (e) => {
				e.preventDefault();
				let paste = e.clipboardData.getData('text');
				let patternClientId = /^$|[0-9a-f]{32}/g;
				if (patternClientId.test(paste)) {
					e.target.value = paste;
					const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity(); 
					document.querySelectorAll('button[class~="allegroAPIButtonsSandbox"]').forEach(btn => { btn.disabled = !inputsValidity });
				}	
			});
			allegroAPIClientIdTextSandbox.addEventListener('input', () => {
				const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
				document.querySelectorAll('button[class~="allegroAPIButtonsSandbox"]').forEach(btn => { btn.disabled = !inputsValidity });
			});

			const allegroAPIClientSecretTextSandbox = document.getElementById('allegroAPIClientSecretTextSandbox');
			allegroAPIClientSecretTextSandbox.value = result.allegroAPIClientSecretSandbox;
			allegroAPIClientSecretTextSandbox.addEventListener('paste', (e) => {
				e.preventDefault();
				let paste = e.clipboardData.getData('text');
				let patternClientSecret = /^$|[0-9a-zA-Z]{64}/g;
				if (patternClientSecret.test(paste)) {
					e.target.value = paste;
					const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientIdTextSandbox').checkValidity();
					document.querySelectorAll('button[class~="allegroAPIButtonsSandbox"]').forEach(btn => { btn.disabled = !inputsValidity });
				}	
			});
			allegroAPIClientSecretTextSandbox.addEventListener('input', () => {
				const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
				document.querySelectorAll('button[class~="allegroAPIButtonsSandbox"]').forEach(btn => { btn.disabled = !inputsValidity });
			});
			const allegroAPIOAuthConnectorTextSandbox = document.getElementById('allegroAPIOAuthConnectorTextSandbox');
			allegroAPIOAuthConnectorTextSandbox.value = result.allegroAPIOAuthConnectorSandbox;
			allegroAPIOAuthConnectorTextSandbox.addEventListener('paste', (e) => {
				e.preventDefault();
				let paste = e.clipboardData.getData('text');
				let patternOAuthConnector = /^$|^https:\/\/script\.google\.com\/macros\/s\/[0-9a-zA-Z-_]{1,}\/exec$/g;
				if (patternOAuthConnector.test(paste)) {
					e.target.value = paste;
					const inputsValidity = document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
					document.querySelectorAll('button[class~="allegroAPIButtonsSandbox"]').forEach(btn => { btn.disabled = !inputsValidity });
				}	
			});
			allegroAPIOAuthConnectorTextSandbox.addEventListener('input', () => {
				const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
				document.querySelectorAll('button[class~="allegroAPIButtonsSandbox"]').forEach(btn => { btn.disabled = !inputsValidity });
			});
		}
		const allegroAPISaveButtonSandbox = document.getElementById('allegroAPISaveButtonSandbox');
		allegroAPISaveButtonSandbox.addEventListener('click', allegroAPISaveButtonClick.bind(null, true));
		const allegroAPILoginButtonSandbox = document.getElementById('allegroAPILoginButtonSandbox');
		allegroAPILoginButtonSandbox.addEventListener('click', allegroAPILoginButtonClick.bind(null, true));
		
		chrome.commands.getAll(commands => {
			const shortcut = commands.find(command => command.name === 'changeAuctionTitle' ).shortcut;
			const shortcutKeys = [];
			for (const key of shortcut.split('+')) {
				shortcutKeys.push(`<kbd>${key}</kbd>`); 
			}
			const shortcutHTML = shortcutKeys.join(' + ');
			document.getElementById('keyboardShortcutSpan').innerHTML = shortcutHTML;
		});
	});
});



function allegroAPISaveButtonClick(sandboxParam = false) {
	const sandbox = (sandboxParam === false ? '' : 'Sandbox');
	console.log('Sandbox mode: ' + sandbox);
	chrome.runtime.sendMessage({action: 'allegroAPISave', clientId: document.getElementById(`allegroAPIClientIdText${sandbox}`).value, clientSecret: document.getElementById(`allegroAPIClientSecretText${sandbox}`).value, oAuthConnector: document.getElementById('allegroAPIOAuthConnectorTextSandbox').value, sandbox: sandboxParam}).then(() => {
		document.getElementById(`allegroAPISaveButton${sandbox}`).disabled = true;
		toastMessage('Zapisano');
	}).catch(error => {
		if (error.name === 'customError') {
			toastMessage(error.message);
		} else {
			toastMessage(`Błąd! Podczas zapisu parametrów Client ID i Cilent Secret wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
		}
	});
}

function allegroAPILoginButtonClick(sandboxParam = false) {
	const environment = (sandboxParam === false ? '' : '.allegrosandbox.pl');
	const mode = (environment === '' ? '' : 'sandbox');
	const sandbox = (environment === '' ? '' : 'Sandbox');
	console.log('Sandbox mode: ' + sandbox);
	chrome.storage.local.get([`allegroAPIClientId${sandbox}`, `allegroAPIClientSecret${sandbox}`, 'allegroAPIOAuthConnectorSandbox']).then(loginData => {
		if (loginData[`allegroAPIClientId${sandbox}`] !== undefined && loginData[`allegroAPIClientSecret${sandbox}`] !== undefined && loginData.allegroAPIOAuthConnectorSandbox !== undefined) {
			(function retry(count = 3) {
				if (!count) {
					toastMessage('Błąd! Nie udało się zalogować użytkownika.');
					return;
				}

				let params = {
					scopes: ['allegro:api:profile:read', 'allegro:api:sale:offers:read', 'allegro:api:sale:offers:write']
				}
				
				if (mode === 'sandbox') {
					fetch(loginData.allegroAPIOAuthConnectorSandbox, {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json'
						},
						body: JSON.stringify({ action: 'getUserCode', clientId: loginData.allegroAPIClientIdSandbox, clientSecret: loginData.allegroAPIClientSecretSandbox, scopes: params.scopes })
					}).then(response => {
						if (response.status === 200) {
							const result = response.json();
							result.then(result => {
								chrome.runtime.sendMessage({ action: 'openLoginPage', url: result.verificationUri }).then(() => {
									toastMessage('Przejdź do strony logowania i zatwierdź wymagane zgody');
									fetch(loginData.allegroAPIOAuthConnectorSandbox, {
										method: 'POST',
										headers: {
											'Content-Type': 'application/json'
										},
										body: JSON.stringify({ action: 'getTokens', clientId: loginData.allegroAPIClientIdSandbox, clientSecret: loginData.allegroAPIClientSecretSandbox, deviceCode: result.deviceCode, interval: result.interval, expirationDate: result.expirationDate })
									}).then(response => {
										if (response.status === 200) {
											let result = response.json();
											result.then(result => {
												if (result?.status === 'success') {
													chrome.storage.local.set({ allegroAccessTokenSandbox: result.accessToken, allegroRefreshTokenSandbox: result.refreshToken }).then(() => {
														result.access_token = result.accessToken;
														(function retry(count = 3) {
															fetch('https://api.allegro.pl.allegrosandbox.pl/me', {
																method: 'GET',
																headers: {
																	'Authorization': `Bearer ${result.access_token}`,
																	'Content-Type': 'application/vnd.allegro.public.v1+json',
																	'Accept': 'application/vnd.allegro.public.v1+json'
																}
															}).then(response => {
																if (response.status === 200) {
																	result = response.json();
																	result.then((result) => {
																		if (result.login !== undefined)	toastMessage(`Zalogowano jako użytkownik ${result.login}`);
																	});
																} else {
																	if (response.status === 403) toastMessage('Błąd! Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
																	else if (response.status !== 401) {
																		if (--count) {
																			const delay = t => new Promise(resolve => setTimeout(resolve, t));
																			delay(3000).then(() => {
																				retry(count);
																			});
																		} else toastMessage(`Błąd! Nie udało się pobrać nazwy użytkownika. Kod odpowiedzi HTTP: ${response.status}`);													
																	}	else {
																		chrome.runtime.sendMessage({ action: 'refreshAllegroAccessToken', mode: 'sandbox' }).then(response => {
																			result.access_token = response.result;
																			retry(--count);	
																		}).catch(error => {
																			if (error.name === 'customError') {
																				toastMessage(error.message);
																			} else {
																				toastMessage(`Błąd! Podczas odświeżania tokena dostępowego wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
																			}
																		});
																	}												
																}
															});
														}());
													}).catch(error => {
														toastMessage(`Błąd! Podczas zapisywania nowych tokenów dostępowych wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
													});
												} else if (result?.status === 'error') {
													toastMessage(`Błąd! Nie udało się uzyskać tokenów dostępowych. ${result.details}`);
												} else toastMessage('Błąd! Nie udało się uzyskać tokenów dostępowych.');
											}).catch(error => {
												toastMessage(`${JSON_DECODE_ERROR} ${error.message}.`);
											});
										} else {
											toastMessage(`Błąd! Podczas pobierania tokenów wystąpił błąd. Kod odpowiedzi HTTP: ${response.status}`);
										}
									});			
								});
							}).catch(error => {
								toastMessage(`${JSON_DECODE_ERROR} ${error.message}.`);
							});
						} else if (response.status === 302) {
						} else {
							if (--count) {
								const delay = t => new Promise(resolve => setTimeout(resolve, t));
								delay(3000).then(() => {
									retry(count);
								});
							} else toastMessage(`Błąd! Spróbuj ponownie później. Kod odpowiedzi HTTP: ${response.status}`);
						}
					}).catch(error => {
						console.log(error.message);
						toastMessage(`Błąd! Podczas wykonywania żądania wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
					});
				} else {
					const redirectUri = document.getElementById('chromeExtensionRedirectURL').innerText;
					chrome.identity.launchWebAuthFlow({'url': `https://allegro.pl${environment}/auth/oauth/authorize?response_type=code&client_id=${document.getElementById(`allegroAPIClientIdText${sandbox}`).value}&redirect_uri=${redirectUri}&scope=${params.scopes.join(' ')}&prompt=confirm`, 'interactive': true, 'abortOnLoadForNonInteractive': false, timeoutMsForNonInteractive: 10000 }).then(redirectUrl => { 
						if (redirectUrl !== undefined) {
							const code = redirectUrl.substring(redirectUrl.indexOf('code=') + 5);
							fetch(`https://allegro.pl${environment}/auth/oauth/token?grant_type=authorization_code&code=${code}&redirect_uri=${redirectUri}`, {
								method: 'POST',
								headers: {
									'Authorization': `Basic ${btoa(loginData[`allegroAPIClientId${sandbox}`] + ':' + loginData[`allegroAPIClientSecret${sandbox}`])}`
								},		
							}).then(response => {
								if (response.status === 200) {
									result = response.json();
									result.then(result => {
										if (result.access_token !== undefined && result.refresh_token !== undefined) {
											chrome.storage.local.set({ [`allegroAccessToken${sandbox}`]: result.access_token, [`allegroRefreshToken${sandbox}`]: result.refresh_token }).then(() => {
												(function retry(count = 3) {
													fetch(`https://api.allegro.pl${environment}/me`, {
														method: 'GET',
														headers: {
															'Authorization': `Bearer ${result.access_token}`,
															'Content-Type': 'application/vnd.allegro.public.v1+json',
															'Accept': 'application/vnd.allegro.public.v1+json'
														}
													}).then(response => {
														if (response.status === 200) {
															result = response.json();
															result.then((result) => {
																if (result.login !== undefined)	toastMessage(`Zalogowano jako użytkownik ${result.login}`);
															}).catch(error => {
																toastMessage(`${JSON_DECODE_ERROR} ${error.message}.`);
															});
														} else {
															if (response.status === 403) toastMessage('Błąd! Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
															else if (response.status !== 401) {
																if (--count) {
																	const delay = t => new Promise(resolve => setTimeout(resolve, t));
																	delay(3000).then(() => {
																		retry(count);
																	});
																} else toastMessage(`Błąd! Nie udało się pobrać nazwy użytkownika. Kod odpowiedzi HTTP: ${response.status}`);													
															}	else {
																chrome.runtime.sendMessage({action: 'refreshAllegroAccessToken', mode: mode}).then(response => {
																	result.access_token = response.result;
																	retry(--count);	
																}).catch(error => {
																	if (error.name === 'customError') {
																		toastMessage(error.message);
																	} else {
																		toastMessage(`Błąd! Podczas odświeżania tokena dostępowego wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
																	}
																});
															}												
														}
													});
												}());	
											}).catch(error => {
												toastMessage(`Błąd! Podczas zapisywania nowych tokenów dostępowych wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
											});									
										}
									}).catch(error => {
										toastMessage(`${JSON_DECODE_ERROR} ${error.message}.`);
									});
								} else if (response.status === 403) {
									console.log(Response.error());
									toastMessage('Błąd! Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
								}	else {
										if (--count) {
											const delay = t => new Promise(resolve => setTimeout(resolve, t));
											delay(3000).then(() => {
												retry(count);
											});
										} else toastMessage(`Błąd! Spróbuj ponownie później. Kod odpowiedzi HTTP: ${response.status}`);
									}
							}).catch(error => {
								console.log(error.message);
								toastMessage(`Błąd! Podczas wykonywania żądania wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
							});
						} 
					}).catch(error => {
						if (error.message === 'The user did not approve access.') toastMessage('Błąd! Proces logowania nie został zakończony.');
					});
				}
			}());
		} else {
			toastMessage('Błąd! Nie znaleziono wymaganych danych (Client ID i Client Secret)');
		}
	}).catch(error => {
		toastMessage(`Błąd! Podczas odczytu danych wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
	});
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	if (request.action === 'showMessageOnOptionsPage') {
		toastMessage(request.message);
	}
});