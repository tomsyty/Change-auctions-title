const JSON_DECODE_ERROR = 'Podczas dekodowania odpowiedzi serwera wystąpił błąd.';
const FETCH_ERROR_MESSAGE = 'Podczas wysyłania żądania wystąpił błąd.';
const HTTP_RESPONSE_CODE = 'Kod odpowiedzi HTTP:';
const REFRESHING_TOKEN_ERROR = 'Nie udało się odświeżyć tokena dostępowego.';
const COULDNT_GET_TOKENS = 'Nie udało się uzyskać tokenów dostępowych.'

chrome.storage.onChanged.addListener( (storageObject, storageArea) => {
	if (storageArea === 'session') {
		if ('message' in storageObject && 'newValue' in storageObject.message) {
			toastMessage(storageObject.message.newValue);
			chrome.storage.session.remove('message');
		}
	}
});

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true); 
    });
  });
}

async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(result); 
    });
  });
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

window.addEventListener('DOMContentLoaded', async () => {
	console.log('--- Załadowano skrypt optionsPage');
	chrome.storage.session.get(['message']).then(result => {
		if (result.message !== undefined) {
			toastMessage(result.message);
			chrome.storage.session.remove('message');
		}
	});

  const redirectUrl = chrome.identity.getRedirectURL('change_auctions_title');
  document.getElementById('chromeExtensionRedirectURL').innerText = redirectUrl;

	document.getElementById('keyboardShortcutChangeLink').addEventListener('click', () => {
		chrome.tabs.create({url: 'chrome://extensions/shortcuts'});
	});

	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['allegroAPIClientId', 'allegroAPIClientSecret', 'allegroAPIClientIdSandbox', 'allegroAPIClientSecretSandbox', 'allegroAPIOAuthConnectorSandbox']);
	} catch (error) {
		toastMessage(`Błąd! W trakcie próby odczytu danych wystąpił błąd. ${error.message}`);
		return;
	}

	if (readedValue.allegroAPIClientId !== undefined && readedValue.allegroAPIClientSecret !== undefined) {	
		const allegroAPIClientIdText = document.getElementById('allegroAPIClientIdText');
		allegroAPIClientIdText.value = readedValue.allegroAPIClientId;
		allegroAPIClientIdText.addEventListener('paste', (e) => {
			e.preventDefault();
			let paste = e.clipboardData.getData('text');
			let patternClientId = /^$|[0-9a-f]{32}/g;
			if (patternClientId.test(paste)) {
				e.target.value = paste;
				const inputsValidity = document.getElementById('allegroAPIClientSecretText').checkValidity();
				document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButton').disabled = true;
			}	
		});
		allegroAPIClientIdText.addEventListener('input', () => {
			const inputsValidity = document.getElementById('allegroAPIClientIdText').checkValidity() && document.getElementById('allegroAPIClientSecretText').checkValidity();
			document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
			document.getElementById('allegroAPILoginButton').disabled = true;
		});

		const allegroAPIClientSecretText = document.getElementById('allegroAPIClientSecretText');
		allegroAPIClientSecretText.value = readedValue.allegroAPIClientSecret;
		allegroAPIClientSecretText.addEventListener('paste', (e) => {
			e.preventDefault();
			let paste = e.clipboardData.getData('text');
			let patternClientSecret = /^$|[0-9a-zA-Z]{64}/g;
			if (patternClientSecret.test(paste)) {
				e.target.value = paste;
				const inputsValidity = document.getElementById('allegroAPIClientIdText').checkValidity();
				document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButton').disabled = true;
			}	
		});
		allegroAPIClientSecretText.addEventListener('input', () => {
			const inputsValidity =  document.getElementById('allegroAPIClientIdText').checkValidity() && document.getElementById('allegroAPIClientSecretText').checkValidity();
			document.getElementById('allegroAPISaveButton').disabled = !inputsValidity;
			document.getElementById('allegroAPILoginButton').disabled = true;
		});

	}
	const allegroAPISaveButton = document.getElementById('allegroAPISaveButton');
	allegroAPISaveButton.addEventListener('click', allegroAPISaveButtonClick.bind(null, false));
	const allegroAPILoginButton = document.getElementById('allegroAPILoginButton');
	allegroAPILoginButton.addEventListener('click', allegroAPILoginButtonClick.bind(null, false));
	if (allegroAPIClientIdText.checkValidity() && allegroAPIClientIdText.value !== '' && allegroAPIClientSecretText.checkValidity && allegroAPIClientSecretText.value !== '') {
		document.getElementById('allegroAPILoginButton').disabled = false;
	}

	if (readedValue.allegroAPIClientIdSandbox !== undefined && readedValue.allegroAPIClientSecretSandbox !== undefined && readedValue.allegroAPIOAuthConnectorSandbox !== undefined) {	
		const allegroAPIClientIdTextSandbox = document.getElementById('allegroAPIClientIdTextSandbox');
		allegroAPIClientIdTextSandbox.value = readedValue.allegroAPIClientIdSandbox;
		allegroAPIClientIdTextSandbox.addEventListener('paste', (e) => {
			e.preventDefault();
			let paste = e.clipboardData.getData('text');
			let patternClientId = /^$|[0-9a-f]{32}/g;
			if (patternClientId.test(paste)) {
				e.target.value = paste;
				const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity(); 
				document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
			}	
		});
		allegroAPIClientIdTextSandbox.addEventListener('input', () => {
			const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
			document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
			document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
		});

		const allegroAPIClientSecretTextSandbox = document.getElementById('allegroAPIClientSecretTextSandbox');
		allegroAPIClientSecretTextSandbox.value = readedValue.allegroAPIClientSecretSandbox;
		allegroAPIClientSecretTextSandbox.addEventListener('paste', (e) => {
			e.preventDefault();
			let paste = e.clipboardData.getData('text');
			let patternClientSecret = /^$|[0-9a-zA-Z]{64}/g;
			if (patternClientSecret.test(paste)) {
				e.target.value = paste;
				const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientIdTextSandbox').checkValidity();
				document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
			}	
		});
		allegroAPIClientSecretTextSandbox.addEventListener('input', () => {
			const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
			document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
			document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
		});
		const allegroAPIOAuthConnectorTextSandbox = document.getElementById('allegroAPIOAuthConnectorTextSandbox');
		allegroAPIOAuthConnectorTextSandbox.value = readedValue.allegroAPIOAuthConnectorSandbox;
		allegroAPIOAuthConnectorTextSandbox.addEventListener('paste', (e) => {
			e.preventDefault();
			let paste = e.clipboardData.getData('text');
			let patternOAuthConnector = /^$|^https:\/\/script\.google\.com\/macros\/s\/[0-9a-zA-Z-_]{1,}\/exec$/g;
			if (patternOAuthConnector.test(paste)) {
				e.target.value = paste;
				const inputsValidity = document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
				document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
				document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
			}	
		});
		allegroAPIOAuthConnectorTextSandbox.addEventListener('input', () => {
			const inputsValidity = document.getElementById('allegroAPIOAuthConnectorTextSandbox').checkValidity() && document.getElementById('allegroAPIClientIdTextSandbox').checkValidity() && document.getElementById('allegroAPIClientSecretTextSandbox').checkValidity();
			document.getElementById('allegroAPISaveButtonSandbox').disabled = !inputsValidity;
			document.getElementById('allegroAPILoginButtonSandbox').disabled = true;
		});
	}
	const allegroAPISaveButtonSandbox = document.getElementById('allegroAPISaveButtonSandbox');
	allegroAPISaveButtonSandbox.addEventListener('click', allegroAPISaveButtonClick.bind(null, true));
	const allegroAPILoginButtonSandbox = document.getElementById('allegroAPILoginButtonSandbox');
	allegroAPILoginButtonSandbox.addEventListener('click', allegroAPILoginButtonClick.bind(null, true));
	if (allegroAPIClientIdTextSandbox.checkValidity() && allegroAPIClientIdTextSandbox.value !== '' && allegroAPIClientSecretTextSandbox.checkValidity && allegroAPIClientSecretTextSandbox.value !== '') {
		document.getElementById('allegroAPILoginButtonSandbox').disabled = false;
	}
	
	const commands = await chrome.commands.getAll();
	const shortcut = commands.find(command => command.name === 'changeAuctionTitle' ).shortcut;
	const shortcutKeys = [];
	for (const key of shortcut.split('+')) {
		shortcutKeys.push(`<kbd>${key}</kbd>`); 
	}
	const shortcutHTML = shortcutKeys.join(' + ');
	document.getElementById('keyboardShortcutSpan').innerHTML = shortcutHTML;
});

async function allegroAPISaveButtonClick(sandboxParam = false) {
	const sandbox = (sandboxParam === false ? '' : 'Sandbox');
	console.log('Sandbox mode: ' + sandbox);
	try {
		const response = await sendMessage({ action: 'allegroAPISave', clientId: document.getElementById(`allegroAPIClientIdText${sandbox}`).value, clientSecret: document.getElementById(`allegroAPIClientSecretText${sandbox}`).value, oAuthConnector: document.getElementById('allegroAPIOAuthConnectorTextSandbox').value, sandbox: sandboxParam });
		document.getElementById(`allegroAPISaveButton${sandbox}`).disabled = true;
		document.getElementById(`allegroAPILoginButton${sandbox}`).disabled = !response.result;
		toastMessage('Zapisano');
	} catch (error) {
		toastMessage(`Błąd! Podczas zapisu parametrów Client ID i Cilent Secret wystąpił błąd. ${error.message}`);
	};
}

async function allegroAPILoginButtonClick(sandboxParam = false) {
	const environment = (sandboxParam === false ? '' : '.allegrosandbox.pl');
	const mode = (environment === '' ? '' : 'sandbox');
	const sandbox = (environment === '' ? '' : 'Sandbox');
	console.log('Sandbox mode: ' + sandbox);
	let loginData;
	try {
		loginData = await readDataFromLocalStorage([`allegroAPIClientId${sandbox}`, `allegroAPIClientSecret${sandbox}`, 'allegroAPIOAuthConnectorSandbox']);
	} catch (error) {
		toastMessage(`Błąd! Podczas odczytu danych wystąpił błąd. ${error.message}`);
		return;
	}
	
	if (loginData[`allegroAPIClientId${sandbox}`] === undefined || loginData[`allegroAPIClientSecret${sandbox}`] === undefined || loginData.allegroAPIOAuthConnectorSandbox === undefined) {
		toastMessage('Błąd! Nie znaleziono danych wymaganych do logowania.');
		return;
	}
	async function login(count = 3) {
		let params = {
			scopes: ['allegro:api:profile:read', 'allegro:api:sale:offers:read', 'allegro:api:sale:offers:write']
		}

		let fetchResponse;
		let fetchData;
		let response;
		
		if (mode === 'sandbox') {
			try {
				fetchResponse = await fetch(loginData.allegroAPIOAuthConnectorSandbox, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json'
					},
					body: JSON.stringify({ action: 'getUserCode', clientId: loginData.allegroAPIClientIdSandbox, clientSecret: loginData.allegroAPIClientSecretSandbox, scopes: params.scopes })
				});
			} catch (error) {
				return Promise.reject(`${FETCH_ERROR_MESSAGE} ${error.message}`);
			}

			if (fetchResponse.status === 200) {
				try {
					fetchData = await fetchResponse.json();
				} catch (error) {
					return Promise.reject(`${JSON_DECODE_ERROR} ${error.message}`);
				}
				
				try {
					await sendMessage({ action: 'openLoginPage', url: fetchData.verificationUri });
				} catch (error) {
					return Promise.reject('Nie udało się otworzyć strony logowania.');
				}

				toastMessage('Przejdź do automatycznie otwartej strony logowania i zatwierdź wymagane zgody');
				try {
					fetchResponse = await fetch(loginData.allegroAPIOAuthConnectorSandbox, {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json'
						},
						body: JSON.stringify({ action: 'getTokens', clientId: loginData.allegroAPIClientIdSandbox, clientSecret: loginData.allegroAPIClientSecretSandbox, deviceCode: fetchData.deviceCode, interval: fetchData.interval, expirationDate: fetchData.expirationDate })
					});
				} catch (error) {
					return Promise.reject(`${FETCH_ERROR_MESSAGE} ${error.message}`);
				}

				if (fetchResponse.status === 200) {
					try {
						fetchData = await fetchResponse.json();
					} catch (error) {
						return Promise.reject(`${JSON_DECODE_ERROR} ${error.message}`);
					}

					if (fetchData?.status === 'success') {
						try {
							await saveDataToLocalStorage({ allegroAccessTokenSandbox: fetchData.accessToken, allegroRefreshTokenSandbox: fetchData.refreshToken });
						} catch (error) {
							return Promise.reject(`Podczas zapisywania nowych tokenów dostępowych wystąpił błąd. ${error.message}`);
						}
						
						fetchData.access_token = fetchData.accessToken;

						async function getLoggedUsername(count = 3) {
							try {
								fetchResponse = await fetch('https://api.allegro.pl.allegrosandbox.pl/me', {
									method: 'GET',
									headers: {
										'Authorization': `Bearer ${fetchData.access_token}`,
										'Content-Type': 'application/vnd.allegro.public.v1+json',
										'Accept': 'application/vnd.allegro.public.v1+json'
									}
								});
							} catch (error) {
								if (--count) {	
									toastMessage(`${REQUEST_RETRY_PART1}${5 - count}${REQUEST_RETRY_PART2}`);
									const delay = t => new Promise(resolve => setTimeout(resolve, t));
									await delay(5000);
									return await getLoggedUsername(count);
								} else return Promise.reject(`${FETCH_ERROR_MESSAGE} ${error.message}`);
							} 

							if (fetchResponse.status === 200) {
								try {
									fetchData = await fetchResponse.json();
								} catch (error) {
									return Promise.reject(`${JSON_DECODE_ERROR} ${error.message}`);
								}
								if (fetchData.login !== undefined) return Promise.resolve(`${fetchData.login}`);
								else return Promise.reject('W odpowiedzi serwera nie otrzymano nazwy zalogowanego użytkownika.');
							} else {
								if (fetchResponse.status === 403) return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
								else if (fetchResponse.status !== 401) {
									if (--count) {
										const delay = t => new Promise(resolve => setTimeout(resolve, t));
										await delay(5000);
										return await getLoggedUsername(count);	
									} else return Promise.reject(`${HTTP_RESPONSE_CODE} ${fetchResponse.status}`);													
								}	else {
									if (--count) {
										try {
											response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: 'sandbox' });
										} catch (error) {
											return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error.message}`);
										}
										fetchData.access_token = response.result;
										return await getLoggedUsername(count);
									} else {
										return Promise.reject(REFRESHING_TOKEN_ERROR);
									}		
								}
							}												
						}

						try {
							const username = await getLoggedUsername();
							return Promise.resolve(toastMessage(`Zalogowano jako użytkownik ${username}`));
						} catch (error) {
							return Promise.reject(`Nie udało się pobrać nazwy zalogowanego użytkownika. ${error}`);
						}	
					} else if (fetchData?.status === 'error' && fetchData?.details !== undefined) {
						return Promise.reject(`${COULDNT_GET_TOKENS} ${fetchData.details}`);
					} else return Promise.reject(COULDNT_GET_TOKENS);			
				} else {
					return Promise.reject(`Podczas pobierania tokenów wystąpił błąd. ${HTTP_RESPONSE_CODE} ${fetchResponse.status}`);
				}
			} else {
				if (--count) {
					const delay = t => new Promise(resolve => setTimeout(resolve, t));
					await delay(5000);
					return await login(count);
				} else return Promise.reject(`Spróbuj ponownie później. ${HTTP_RESPONSE_CODE} ${fetchResponse.status}`);
			}	
		} else {
			const redirectUri = document.getElementById('chromeExtensionRedirectURL').innerText;
			let redirectUrl;
			try {
				redirectUrl = await chrome.identity.launchWebAuthFlow({ 'url': `https://allegro.pl/auth/oauth/authorize?response_type=code&client_id=${document.getElementById('allegroAPIClientIdText').value}&redirect_uri=${redirectUri}&scope=${params.scopes.join(' ')}&prompt=confirm`, 'interactive': true, 'abortOnLoadForNonInteractive': false, timeoutMsForNonInteractive: 10000 });
			} catch (error) {
				if (error.message === 'The user did not approve access.') return Promise.reject('Proces logowania nie został zakończony.');
			}

			if (redirectUrl !== undefined) {
				const code = redirectUrl.substring(redirectUrl.indexOf('code=') + 5);
				try {
					fetchResponse = await fetch(`https://allegro.pl/auth/oauth/token?grant_type=authorization_code&code=${code}&redirect_uri=${redirectUri}`, {
						method: 'POST',
						headers: {
							'Authorization': `Basic ${btoa(loginData['allegroAPIClientId'] + ':' + loginData['allegroAPIClientSecret'])}`
						},		
					});
				} catch (error) {
					return Promise.reject(`Spróbuj ponownie później. ${HTTP_RESPONSE_CODE} ${fetchResponse.status}`);
				}
				if (fetchResponse.status === 200) {
					try {
						fetchData = await fetchResponse.json();
					} catch (error) {
						return Promise.reject(`${JSON_DECODE_ERROR} ${error.message}`);
					}

					if (fetchData.access_token !== undefined && fetchData.refresh_token !== undefined) {
						try {
							await saveDataToLocalStorage({ allegroAccessToken: fetchData.access_token, allegroRefreshToken: fetchData.refresh_token });
						} catch (error) {
							return Promise.reject(`Podczas zapisywania nowych tokenów dostępowych wystąpił błąd. ${error.message}`);
						}
						
						async function getLoggedUsername(count = 3) {
							try {
								fetchResponse = await fetch('https://api.allegro.pl/me', {
									method: 'GET',
									headers: {
										'Authorization': `Bearer ${fetchData.access_token}`,
										'Content-Type': 'application/vnd.allegro.public.v1+json',
										'Accept': 'application/vnd.allegro.public.v1+json'
									}
								});
							} catch (error) {
								if (--count) {	
									toastMessage(`${REQUEST_RETRY_PART1}${5 - count}${REQUEST_RETRY_PART2}`);
									const delay = t => new Promise(resolve => setTimeout(resolve, t));
									await delay(5000);
									return await getLoggedUsername(count);
								} else return Promise.reject(`${FETCH_ERROR_MESSAGE} ${error.message}`);
							} 

							if (fetchResponse.status === 200) {
								try {
									fetchData = await fetchResponse.json();
								} catch (error) {
									return Promise.reject(`${JSON_DECODE_ERROR} ${error.message}`);
								}
								if (fetchData.login !== undefined) return Promise.resolve(fetchData.login);
								else return Promise.reject('W odpowiedzi serwera nie otrzymano nazwy zalogowanego użytkownika.');
							} else {
								if (fetchResponse.status === 403) return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
								else if (fetchResponse.status !== 401) {
									if (--count) {
										const delay = t => new Promise(resolve => setTimeout(resolve, t));
										await delay(5000);
										return await getLoggedUsername(count);	
									} else return Promise.reject(`${HTTP_RESPONSE_CODE} ${fetchResponse.status}`);													
								}	else {
									if (--count) {
										try {
											response = await sendMessage({ action: 'refreshAllegroAccessToken', mode: 'allegro' });
										} catch (error) {
											return Promise.reject(`Podczas odświeżania tokena dostępowego wystąpił błąd. ${error.message}`);
										}
										fetchData.access_token = response.result;
										return await getLoggedUsername(count);
									} else {
										return Promise.reject(REFRESHING_TOKEN_ERROR);
									}		
								}
							}												
						}

						try {
							const username = await getLoggedUsername();
							return Promise.resolve(`Zalogowano jako użytkownik ${username}`);
						} catch (error) {
							return Promise.reject(`Nie udało się pobrać nazwy zalogowanego użytkownika. ${error}`);
						}															
					}					
				} else if (fetchResponse.status === 403) {
					return Promise.reject('Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
				}	else {
					if (--count) {
						const delay = t => new Promise(resolve => setTimeout(resolve, t));
						delay(5000)
						return await login(count);
					} else return Promise.reject(`Spróbuj ponownie później. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
				}	
			} 
		}
	}

	try {
		const result = await login();
		toastMessage(result);
	} catch (error) {
		toastMessage(`Błąd! ${error}`);
	}
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	if (request.action === 'showMessageOnOptionsPage') {
		toastMessage(request.message);
	}
});