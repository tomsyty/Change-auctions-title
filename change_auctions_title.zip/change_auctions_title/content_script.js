const JSON_DECODE_ERROR = 'Błąd! Podczas dekodowania odpowiedzi serwera wystąpił błąd.';
const DETAILED_ERROR_MESSAGE = `Szczegóły (oryginalna treść błędu):`;
const REQUEST_RETRY_PART1 = 'Ponawianie próby wysyłania żądania (';
const REQUEST_RETRY_PART2 = ' z 5), proszę czekać...';

const allowedCharsArray = [ 
  ' ', '!', '"', '#', '$', '%', '&', "'", '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@',
  'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 
  'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '§', '€', '$', '°', 
  '±', '²', '³', '´', 'µ', 'À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', '×', 'Ø', 'Ù', 'Ú', 'Û', 
  'Ü', 'Ý', 'Þ', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ð', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 
  'þ', 'ÿ', 'Ā', 'ā', 'Ă', 'ă', 'Ą', 'ą', 'Ć', 'ć', 'Č', 'č', 'Ď', 'ď', 'Ĕ', 'ĕ', 'Ė', 'ė', 'Ę', 'ę', 'Ě', 'ě', 'Ğ', 'ğ', 'Ģ', 'ģ', 'Ī', 'ī', 'İ', 'Ĺ', 'ĺ', 'Ľ', 'ľ', 
  'Ł', 'ł', 'Ń', 'ń', 'Ņ', 'ņ', 'Ň', 'ň', 'Ō', 'ō', 'Ŏ', 'ŏ', 'Ő', 'ő', 'Œ', 'œ', 'Ŕ', 'ŕ', 'Ř', 'ř', 'Ś', 'ś', 'Ŝ', 'ŝ', 'Ş', 'ş', 'Š', 'š', 'Ť', 'ť', 'Ū', 'ū', 'Ů', 
  'ů', 'Ÿ', 'Ź', 'ź', 'Ż', 'ż', 'Ž', 'ž', 'Μ', 'Σ', 'Φ', 'β', 'μ', 'σ', 'φ', 'Ё', 'Є', 'І', 'Ї', 'А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н',
  'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ь', 'Ю', 'Я', 'а', 'б', 'в', 'г', 'д', 'е', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 
  'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ь', 'ю', 'я', 'ё', 'є', 'і', 'ї', 'Ґ', 'ґ', 'Ӧ', 'ӧ', 'ą', 'Ą', 'ć', 'Ć', 'ę', 'Ę', 'ł', 'Ł', 'ń', 'Ń', 'ó', 'Ó',
  'ś', 'Ś', 'ź', 'Ź', 'ż', 'Ż', 'á', 'Á', 'č', 'Č', 'ď', 'Ď', 'é', 'É', 'ě', 'Ě', 'í', 'Í', 'ň', 'Ň', 'ó', 'Ó', 'ř', 'Ř', 'š', 'Š', 'ť', 'Ť', 'ú', 'Ú', 'ů', 'Ů', 'ý', 
  'Ý', 'ž', 'Ž', 'á', 'Á', 'ä', 'Ä', 'č', 'Č', 'ď', 'Ď', 'é', 'É', 'í', 'Í', 'ľ', 'Ľ', 'ĺ', 'Ĺ', 'ň', 'Ň', 'ó', 'Ó', 'ô', 'Ô', 'ŕ', 'Ŕ', 'š', 'Š', 'ť', 'Ť', 'ú', 'Ú',
  'ý', 'Ý', 'ž', 'Ž', 'č', 'Č', 'š', 'Š', 'ž', 'Ž', 'ć', 'Ć', 'đ', 'Đ', 'á', 'Á', 'é', 'É', 'í', 'Í', 'ó', 'Ó', 'ö', 'Ö', 'ő', 'Ő', 'ú', 'Ú', 'ü', 'Ü'
];

const allowedKeysArray = [
  'ArrowLeft', 'ArrowUp', 'ArrowDown', 'ArrowRight', 'Delete', 'Backspace', 'PageUp', 'PageDown', 'Home', 'End'
];

(function addStylesheet() {	
  const link = document.createElement('link');
  link.type = 'text/css';
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20,400,0,0';
  document.head.appendChild(link);
})();

window.addEventListener('load', () => {
	console.log('Załadowano skrypt changeAuctionsTitle');	
  const toast = document.createElement('div');
  toast.id = 'aeToast';
  toast.classList.add('aeToastHidden');
  document.body.appendChild(toast);
	changeAuctionsTitle();
});

function changeAuctionsTitle() {
  let preloadIconsContainer = document.getElementById('preloadIconsContainer');
	if (preloadIconsContainer === null) {
		preloadIconsContainer = document.createElement('div');
		preloadIconsContainer.id = 'preloadIconsContainer';
		document.body.appendChild(preloadIconsContainer);
	}
	const iconConfirm = document.createElement('span');
	iconConfirm.className = 'material-symbols-outlined';
	const iconConfirmNode = document.createTextNode('check_circle');
	iconConfirm.appendChild(iconConfirmNode);
	const iconCancel = document.createElement('span');
	iconCancel.className = 'material-symbols-outlined';
	const iconCancelNode = document.createTextNode('cancel');
	iconCancel.appendChild(iconCancelNode);
	preloadIconsContainer.appendChild(iconConfirm);
	preloadIconsContainer.appendChild(iconCancel);

  const sandbox = (window.location.href.startsWith('https://allegro.pl.allegrosandbox.pl') ? 'Sandbox' : '');
  const environment = (sandbox === 'Sandbox' ? '.allegrosandbox.pl' : '');
  observeOffersList(sandbox, environment);
}

function observeOffersList(sandbox, environment) {
	const observedTable = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
	if (observedTable === null) {
		const offersTableObserver = new MutationObserver(mutations => {
			mutations.forEach(mutation => {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
            const delay = t => new Promise(resolve => setTimeout(resolve, t));
				    delay(0).then(() => {
						  observeOffersList(sandbox, environment);
            });
            return;  
					}
				}
			});
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
	}	else {
		const urlObserver = new MutationObserver(() => {
			if (window.location.href !== previousUrl) {
				previousUrl = window.location.href;
				urlObserver.disconnect();
				const delay = t => new Promise(resolve => setTimeout(resolve, t));
				delay(0).then(() => {
					observeOffersList(sandbox, environment);
				});
				return;
			}
		});
    if (window.location.href !== previousUrl) {
      previousUrl = window.location.href;
		  urlObserver.observe(document, {	subtree: true, childList: true });
      observeAuctionsTitle(environment, observedTable);
    }
		urlObserver.observe(document, {	subtree: true, childList: true });
	}  	
}

function observeAuctionsTitle(environment, observedTable) {
  observedTable.tHead.rows[0].children[0].style.width = '40%';
  const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      mutation.addedNodes.forEach(addedNode => {
        if (addedNode.nodeName === 'TR') {
          let link = addedNode.querySelector(`a[href*="https://allegro.pl${environment}/oferta/"]`);
          if (link !== null) {
            const auctionId = link.href.split('-').pop();
            chrome.storage.session.get([`${auctionId}`]).then(result => {
              if (Object.keys(result).length > 0) {
                if ((`${result[`${auctionId}`].text}` !== undefined) && (`${result[`${auctionId}`].text}` !== link.innerText)) {     
                  link.innerText = `${result[`${auctionId}`].text}`;
                }               
              }
            }).catch(() => {
              toastMessage('Błąd! Nie udało się odczytać danych z pamięci. Jeżeli zmieniałeś tytuły aukcji, odśwież stronę aby wczytać zmiany.');
            });
          }
        };
      });
    });
  });

  observer.observe(observedTable, { subtree: true, childList: true });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	const action = request.action;

	switch (action) {
    case 'allowEditing': {
      const environment = (window.location.href.startsWith('https://allegro.pl.allegrosandbox.pl') ? '.allegrosandbox.pl' : '');
      const auctionTitleLink = document.querySelector(`a[href*="https://allegro.pl${environment}/oferta/"]:hover`);
      if (auctionTitleLink === null) {
        toastMessage(`Najedź kursorem nad tytuł oferty który chcesz zmienić i wciśnij ${request.shortcut}`);
        break;
      }
      let actionsBox = document.getElementById('actionsBox');
      const commonParent = auctionTitleLink.parentElement.parentElement.parentElement;
      if (actionsBox !== null) {
        if (actionsBox.parentElement === commonParent) {
          break;
        }
        document.getElementsByClassName('activeEdit')[0]?.blur();
      }
      
      auctionTitleLink.contentEditable = true;
      auctionTitleLink.focus();
      auctionTitleLink.classList.add('activeEdit');

      actionsBox = document.createElement('div');
      actionsBox.id = 'actionsBox';
      actionsBox.innerHTML = '<span id="charCounter"></span> <span id="confirmButton" class="material-symbols-outlined">check_circle</span> <span id="cancelButton" class="material-symbols-outlined">cancel</span>';

      commonParent.insertAdjacentElement('beforeend', actionsBox);
      const charCounter = document.getElementById('charCounter');
      charCounter.innerText = auctionTitleLink.innerText.length;
      auctionTitleLink.dataset.originalText = auctionTitleLink.innerText;
      document.getElementById('confirmButton').addEventListener('mousedown', confirmButtonClick.bind(null, environment, auctionTitleLink, auctionTitleLink.innerText, auctionTitleLink.href.split('-').pop()));
      document.getElementById('confirmButton').addEventListener('mouseenter', confirmButtonEnter.bind(null, auctionTitleLink));

      auctionTitleLink.addEventListener('blur', auctionTitleLinkBlur, {once: true});
      auctionTitleLink.addEventListener('keydown', auctionTitleLinkKeyDown);
      auctionTitleLink.addEventListener('keyup', auctionTitleLinkKeyUp);
      auctionTitleLink.addEventListener('input', auctionTitleLinkInput);
      auctionTitleLink.addEventListener('paste', auctionTitleLinkPaste);
      break;
    }
  }
});

  function setCaretPosition(element, caretPosition) {
    const range = document.createRange();
    const selection = document.getSelection();
    if (caretPosition > element.innerText.length) caretPosition = element.innerText.length;
    range.setStart(element.childNodes[0], caretPosition);
    range.collapse(true);
    selection.removeAllRanges();
    selection.addRange(range);
  }

  function confirmButtonEnter(auctionTitleLink) {
    const text = auctionTitleLink.innerText;
    auctionTitleLink.innerText = text.replaceAll(/[\r\n]/g, ' ').replaceAll(/\s{2,}/g, ' ').trim();
    const keyUpEvent = new KeyboardEvent('keyup');
    auctionTitleLink.dispatchEvent(keyUpEvent);
  }

  function auctionTitleLinkBlur(e) {
    const auctionTitleLink = e.target;
    auctionTitleLink.innerText = auctionTitleLink.dataset.originalText;
    delete auctionTitleLink.dataset.originalText;
    delete auctionTitleLink.dataset.insertionPoint;
    delete auctionTitleLink.dataset.selectionStart;
    delete auctionTitleLink.dataset.selectionEnd;
    auctionTitleLink.classList.remove('activeEdit', 'wrongValue');
    auctionTitleLink.removeAttribute('contentEditable');
    const actionsBox = document.getElementById('actionsBox');
    if (actionsBox !== null) {         
      actionsBox.remove();
    }

    const additionalInfoText = document.getElementById('additionalInfoText');
    if (additionalInfoText !== null) {
      additionalInfoText.remove();
    }
    
    auctionTitleLink.removeEventListener('keydown', auctionTitleLinkKeyDown);
    auctionTitleLink.removeEventListener('keyup', auctionTitleLinkKeyUp);
    auctionTitleLink.removeEventListener('input', auctionTitleLinkInput);
    auctionTitleLink.removeEventListener('paste', auctionTitleLinkPaste);
  }

  function auctionTitleLinkKeyDown(e) {
    if (e.key === 'Escape') {
      const blurEvent = new Event('blur');
      e.target.dispatchEvent(blurEvent);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const confirmButton = document.getElementById('confirmButton');
      if (confirmButton !== null) {
        const mouseEnterEvent = new MouseEvent('mouseenter');
        confirmButton.dispatchEvent(mouseEnterEvent);
        const mouseDownEvent = new MouseEvent('mousedown');
        confirmButton.dispatchEvent(mouseDownEvent);
      }
    } else if (e.key == 'z' && e.ctrlKey) {
      if ('history' in e.target.dataset) {
        e.preventDefault();
        e.target.innerText = e.target.dataset.history;
        setCaretPosition(e.target, e.target.dataset.insertionPoint);
        if ('selectionStart' in e.target.dataset) {
          const selection = document.getSelection();
          selection.setBaseAndExtent(e.target.childNodes[0], e.target.dataset.selectionStart, e.target.childNodes[0], e.target.dataset.selectionEnd);
          delete e.target.dataset.selectionStart;
          delete e.target.dataset.selectionEnd;
        }
        delete e.target.dataset.history;
        delete e.target.dataset.insertionPoint;
      }
    } else if (allowedKeysArray.indexOf(e.key) !== -1) {
      return;
    } else if (allowedCharsArray.indexOf(e.key) === -1) {
      e.preventDefault();
    }
  }

  function auctionTitleLinkInput(e) {
    if ('history' in e.target.dataset) {
      delete e.target.dataset.history;
      delete e.target.dataset.insertionPoint;
      delete e.target.dataset.selectionStart;
      delete e.target.dataset.selectionEnd;
    }
  }

  function auctionTitleLinkKeyUp(e) {
    let invalidValue = false;
    const charCounter = document.getElementById('charCounter');
    charCounter.innerText = e.target.innerText.length;
    if (charCounter.innerText > 75 || charCounter.innerText === '0') {
      additionalInfoTextAdd('nieprawidłowa długość', e.target.parentElement);
      invalidValue = true;
    } else {
      additionalInfoTextRemove('nieprawidłowa długość');
    }

    if (e.target.innerText.search(/\s{2,}/) !== -1) {
      additionalInfoTextAdd('podwójna spacja', e.target.parentElement);
      invalidValue = true;
    } else {
      additionalInfoTextRemove('podwójna spacja');
    }

    if (e.target.innerText.search(/^\s/) !== -1) {
      additionalInfoTextAdd('spacja na początku', e.target.parentElement);
      invalidValue = true;
    } else {
      additionalInfoTextRemove('spacja na początku');
    }
    
    if (e.target.innerText.search(/\s+$/) !== -1) {
      additionalInfoTextAdd('spacja na końcu', e.target.parentElement);
      invalidValue = true;
    } else {
      additionalInfoTextRemove('spacja na końcu');
    }

    if (invalidValue) e.target.classList.add('wrongValue');
    else e.target.classList.remove('wrongValue');
  }

  function auctionTitleLinkPaste(e) {
    e.preventDefault();
    const target = (e.target.nodeName === 'A' ? e.target : e.target.parentNode);
    target.dataset.history = target.textContent;
    const clipboardData = e.clipboardData.getData('text');

    let filteredString = clipboardData.replaceAll(/[\r\n]/g, ' ').replaceAll(/\s{2,}/g, ' ');
    const filteredArray = filteredString.split('').map(char => {
      if (allowedCharsArray.indexOf(char) !== -1) return char;
      else return '';
    });

    filteredString = filteredArray.join(''); 
    if (filteredString !== clipboardData) {
      additionalInfoTextAdd('wklejony tekst został zmodyfikowany', target.parentElement);
      const delay = t => new Promise(resolve => setTimeout(resolve, t));
      delay(3000).then(() => {
        additionalInfoTextRemove('wklejony tekst został zmodyfikowany');
      });      
    }
    
    let caretPosition = null;
    const selection = document.getSelection();
    const range = document.createRange();

    if (!selection.isCollapsed) {
      target.dataset.selectionStart = selection.anchorOffset;
      target.dataset.selectionEnd = selection.focusOffset;
      selection.deleteFromDocument();
    }
      
    if (range.collapsed) {
      const marker = document.createTextNode('\0');
      selection.getRangeAt(0).insertNode(marker);
      caretPosition = target.innerText.indexOf('\0');
      marker.parentNode.removeChild(marker);
    }

    target.dataset.insertionPoint = caretPosition;
    const linkText = target.innerText;
    const newLinkText = [linkText.slice(0, caretPosition), filteredString, linkText.slice(caretPosition)].join('');
    
    target.innerText = newLinkText;  
    if (newLinkText !== target.innerText) {
      additionalInfoTextAdd('wklejony tekst został zmodyfikowany', target.parentElement);
      const delay = t => new Promise(resolve => setTimeout(resolve, t));
      delay(3000).then(() => {
        additionalInfoTextRemove('wklejony tekst został zmodyfikowany');
      });      
    }
    setCaretPosition(target, caretPosition + filteredString.length);
  };

  function confirmButtonClick(environment, auctionTitleLink, originalText, auctionId) {
    auctionTitleLink.innerText = auctionTitleLink.innerText.replaceAll(/\s{2,}/g, ' ');
    if (auctionTitleLink.innerText.length > 75 || auctionTitleLink.innerText.length === 0) {
      toastMessage('Błąd! Nieprawidłowa długość tytułu aukcji');
      const blurEvent = new Event('blur');
      auctionTitleLink.dispatchEvent(blurEvent);
      return;
    }

    if (auctionTitleLink.innerText === originalText) {
      toastMessage('Nie ma nic do zmiany');
      const blurEvent = new Event('blur');
      auctionTitleLink.dispatchEvent(blurEvent);
      return;
    }

    function removeEditable() {
      auctionTitleLink.removeEventListener('blur', auctionTitleLinkBlur);
      auctionTitleLink.removeEventListener('keydown', auctionTitleLinkKeyDown);
      auctionTitleLink.removeEventListener('keyup', auctionTitleLinkKeyUp);
      auctionTitleLink.removeEventListener('input', auctionTitleLinkInput);
      auctionTitleLink.removeEventListener('paste', auctionTitleLinkPaste);

      auctionTitleLink.classList.remove('activeEdit', 'wrongValue');
      const actionsBox = document.getElementById('actionsBox');
      if (actionsBox !== null) {         
        actionsBox.remove();
      }
      const additionalInfoText = document.getElementById('additionalInfoText');
      if (additionalInfoText !== null) {
        additionalInfoText.remove();
      }
      auctionTitleLink.removeAttribute('contentEditable');
    }

    removeEditable();

    (async function changeAuctionTitle(count = 5) {
      let response;
      let accessToken;
      try {
        response = await chrome.runtime.sendMessage({action: 'getAllegroAccessToken'});
      } catch(error) {
         if (error.name === 'customError') {
          toastMessage(error.message);
        } else {
          toastMessage(`Błąd! Podczas pobierania tokena dostępowego wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
        }
        return;
      }
      
      accessToken = response.result;
      if (accessToken === undefined) {
        toastMessage('Błąd! Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
        return;
      }

      try {
        response = await fetch(`https://api.allegro.pl${environment}/sale/product-offers/${auctionId}`, {
          'method': 'GET',
          'headers': {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/vnd.allegro.public.v1+json',
            'Accept': 'application/vnd.allegro.public.v1+json'
          }
        });
      } catch(error) {
        toastMessage(`Błąd! Podczas wysyłania żądania wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
        auctionTitleLink.innerText = originalText;
        return;
      };

      if (response.status === 200) {
        try {
          response = await fetch(`https://api.allegro.pl${environment}/sale/product-offers/${auctionId}`, {
            'method': 'PATCH',
            'headers': {
              'Authorization': `Bearer ${accessToken}`,
              'Content-Type': 'application/vnd.allegro.public.v1+json',
              'Accept': 'application/vnd.allegro.public.v1+json'
            },
            body: JSON.stringify({'name': auctionTitleLink.innerText})
          });
        } catch(error) {
          toastMessage(`Błąd! Podczas wysyłania żądania wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
          auctionTitleLink.innerText = originalText;
          return;
        };

        if (response.status === 200) {   
          toastMessage('Zmieniono!');
          chrome.storage.session.set({ 
            [`${auctionId}`]: {
              text: auctionTitleLink.innerText
            }
          }).catch(() => {
            toastMessage(`Błąd! Zmieniono tytuł aukcji, jednak na liście może widnieć poprzedni. Odczekaj chwilę i odśwież stronę celem wczytania zaktualizowanej listy aukcji. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
          });
        } else if (response.status === 202) {
          toastMessage('Trwa wprowadzanie zmian...');
          chrome.storage.session.set({ 
            [`${auctionId}`]: {
              text: auctionTitleLink.innerText
            }
          }).catch(() => {
            toastMessage(`Błąd! Zmieniono tytuł aukcji, jednak na liście może widnieć poprzedni. Odczekaj chwilę i odśwież stronę celem wczytania zaktualizowanej listy aukcji. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
          });
        } else if (response.status === 401) {
          if (--count) {	
            toastMessage(`${REQUEST_RETRY_PART1}${5 - count}${REQUEST_RETRY_PART2}`);
            try {
              response = await chrome.runtime.sendMessage({action: 'refreshAllegroAccessToken'});
            } catch (error) {
              if (error.name === 'customError') {
                toastMessage(error.message);
              } else {
                toastMessage(`Błąd! Podczas odświeżania tokena dostępowego wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
              }
              auctionTitleLink.innerText = originalText;
              return;
            }  
            if (response.result === undefined) {
              toastMessage('Błąd! Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
              auctionTitleLink.innerText = originalText;
              return;
            }          
            changeAuctionTitle(count); 
          } else {
            toastMessage(`Błąd! Nie udało się zmienić tytułu aukcji. Nie udało się zalogować użytkownika.`);
            auctionTitleLink.innerText = originalText;
          }
        } else if (response.status === 403) {
          toastMessage('Błąd! Upewnij się że na stronie rejestracji aplikacji zaznaczyłeś właściwe uprawnienia.');
          auctionTitleLink.innerText = originalText;
        } else {
          if (--count) {
            const delay = t => new Promise(resolve => setTimeout(resolve, t));
            delay(5000).then(() => {
              changeAuctionTitle(count); 
            });
            toastMessage(`${REQUEST_RETRY_PART1}${5 - count}${REQUEST_RETRY_PART2}`);
          } else {
            toastMessage(`Błąd! Nie udało się pobrać szczegółów dotyczących oferty. Kod odpowiedzi HTTP: ${response.status}`);
            auctionTitleLink.innerText = originalText;
          }											
        }
      } else if (response.status === 401) {
        if (--count) {
          toastMessage(`${REQUEST_RETRY_PART1}${5 - count}${REQUEST_RETRY_PART2}`);
          try {
            response = await chrome.runtime.sendMessage({action: 'refreshAllegroAccessToken'});	
          } catch (error) {
            if (error.name === 'customError') {
              toastMessage(error.message);
            } else {
              toastMessage(`Błąd! Podczas odświeżania tokena dostępowego wystąpił błąd. ${DETAILED_ERROR_MESSAGE} ${error.message}`);
            }
            auctionTitleLink.innerText = originalText;
            return;
          }		
          if (response.result === undefined) {
            toastMessage('Błąd! Brak tokena dostępowego - spróbuj ponownie zalogować aplikację do Allegro na stronie opcji rozszerzenia.');
            auctionTitleLink.innerText = originalText;
            return;
          }							      												            
          changeAuctionTitle(count); 
        } else {
          toastMessage('Błąd! Nie udało się zmienić tytułu aukcji. Nie udało się zalogować użytkownika.');
          auctionTitleLink.innerText = originalText;
        }
      } else {
        if (--count) {
          toastMessage(`${REQUEST_RETRY_PART1}${5 - count}${REQUEST_RETRY_PART2}`);
          const delay = t => new Promise(resolve => setTimeout(resolve, t));
          delay(5000).then(() => {
            changeAuctionTitle(count);
          });
        } else {
          toastMessage(`Błąd! Nie udało się zmienić tytułu aukcji. Kod odpowiedzi HTTP: ${response.status}`);
          auctionTitleLink.innerText = originalText;
        }
      }
    })(); 
  }

function additionalInfoTextAdd(textToAdd, parent) {
  let additionalInfoText = document.getElementById('additionalInfoText');
  if (additionalInfoText === null) {
    additionalInfoText = document.createElement('div');
    additionalInfoText.id = 'additionalInfoText';
    additionalInfoText.innerText = textToAdd;
    parent.insertAdjacentElement('afterend', additionalInfoText);
  } else {
    let additionalInfoTextArray = additionalInfoText.innerText.split('\n');
    const itemIndex = additionalInfoTextArray.findIndex(element => element === textToAdd);
    if (itemIndex === -1) {
      additionalInfoTextArray.push(textToAdd);
      additionalInfoText.innerText = additionalInfoTextArray.join('\n');
    }
  }
}

function additionalInfoTextRemove(textToRemove) {
  let additionalInfoText = document.getElementById('additionalInfoText');
  if (additionalInfoText) {
    let additionalInfoTextArray = additionalInfoText.innerText.split('\n');
    const indexToDelete = additionalInfoTextArray.findIndex(element => element === textToRemove);
    if (indexToDelete !== -1) {
      additionalInfoTextArray.splice(indexToDelete, 1);
      additionalInfoText.innerText = additionalInfoTextArray.join('\n');
      if (additionalInfoTextArray.length === 0) {
        additionalInfoText.remove();
      }
    }
  }
}